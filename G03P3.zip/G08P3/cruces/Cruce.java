package cruces;

import individuo.Individuo;

public interface Cruce{
	public void cruza(Individuo in1, Individuo in2);

}
