package mutacion;

import individuo.Individuo;

public interface Mutacion {
	public void muta(Individuo i);
}
