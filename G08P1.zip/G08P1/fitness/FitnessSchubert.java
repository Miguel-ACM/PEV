package fitness;

import individuo.Individuo;

public class FitnessSchubert implements Fitness{
	
	public double fitness(Individuo individuo)
	{
		float[] fenotipo = individuo.getFenotipo();
		if (fenotipo.length < 2)
			return -1; //TODO CONTROL DE EXCEPCIONES
		double firstSum = 0;
		double secondSum = 0;
		
		for (int i = 1; i <= 5; i++)
		{
			firstSum += i * Math.cos((i + 1) * fenotipo[0] + i);
			secondSum += i * Math.cos((i + 1) * fenotipo[1] + i);
			
		}
		return firstSum * secondSum;
	}
	
	@Override
	public float[][] getLimits() {
		float[][] limits = {{-10f, 10f}, {-10f, 10f}};
		return limits;
	}
	
	@Override
	public boolean maximiza() {
		return false;
	}
}