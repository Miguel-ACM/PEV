package fitness;

import individuo.Individuo;

public interface Fitness {
	//Obtiene el fitness del individuo
	public int fitness(Individuo individuo);
	
	public int getSize();
}
